{
	rm -f /data/adb/ksu/bin/ksu_susfs
	#rm -f /data/adb/ksu/bin/sus_su
	#rm -f /data/adb/ksu/bin/sus_su_drv_path
} 2>/dev/null
